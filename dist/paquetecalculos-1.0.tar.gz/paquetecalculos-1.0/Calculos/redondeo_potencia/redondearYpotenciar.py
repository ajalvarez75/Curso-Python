def potencia(base,exponente):
	print("la potencia es: ", base**exponente)

def redondear(numero):
	print("el numero redondeado es: ", round(numero))